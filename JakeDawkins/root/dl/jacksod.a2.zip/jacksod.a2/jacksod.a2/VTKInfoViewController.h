//
//  VTKInfoViewController.h
//  jacksod.a2
//
//  Created by Jake Dawkins on 9/23/14.
//  Copyright (c) 2014 Jake Dawkins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VTKInfoViewController : UIViewController

@end
