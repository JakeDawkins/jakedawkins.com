//
//  jacksod_a2Tests.m
//  jacksod.a2Tests
//
//  Created by Jake Dawkins on 9/20/14.
//  Copyright (c) 2014 Jake Dawkins. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface jacksod_a2Tests : XCTestCase

@end

@implementation jacksod_a2Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
