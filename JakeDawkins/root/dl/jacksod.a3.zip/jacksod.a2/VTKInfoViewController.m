//
//  VTKInfoViewController.m
//  jacksod.a2
//
//  Created by Jake Dawkins on 9/23/14.
//  Copyright (c) 2014 Jake Dawkins. All rights reserved.
//

#import "VTKInfoViewController.h"

@interface VTKInfoViewController ()

@end

@implementation VTKInfoViewController
/*
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES];   //it hides
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO];    // it shows
}
*/
- (void)viewDidLoad
{
    [super viewDidLoad];

    // Do any additional setup after loading the view.
    self.automaticallyAdjustsScrollViewInsets = NO;


}


@end
