//
//  SwagLevel.h
//  Swag O'Meter
//
//  Created by Jake Dawkins on 9/5/14.
//  Copyright (c) 2014 Jake Dawkins. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SwagLevel : NSObject

+(NSNumber *)getSwagLevel:(NSString*)name;


@end
