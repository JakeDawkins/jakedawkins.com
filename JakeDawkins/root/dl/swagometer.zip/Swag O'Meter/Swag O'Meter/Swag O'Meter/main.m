//
//  main.m
//  Swag O'Meter
//
//  Created by Jake Dawkins on 9/4/14.
//  Copyright (c) 2014 Jake Dawkins. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SwagOMeterAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SwagOMeterAppDelegate class]));
    }
}
