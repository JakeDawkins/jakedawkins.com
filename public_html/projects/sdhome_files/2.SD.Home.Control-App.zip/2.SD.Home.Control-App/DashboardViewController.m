//
//  DashboardViewController.m
//  2.SD.Home.Control-App
//
//  Created by Jake Dawkins on 11/17/14.
//  Copyright (c) 2014 Thunder Ducklings. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "DashboardViewController.h"

// Octave sound effects
#import "UIControl+Sound.h"

@interface DashboardViewController()

//outlets in .h


@property (weak, nonatomic) IBOutlet UIView *contentView;

@end



@implementation DashboardViewController
AppDelegate *homeAppDelegate;

-(void)setColorOfCurrentTempHome
{
    float difference = fabsf(homeAppDelegate.setTemperature - homeAppDelegate.currentTemperature);
    
    if(difference <3)
    {
        self.currentTempLabel.textColor = [UIColor greenColor];
    }
    else
    {
        
        self.currentTempLabel.textColor = [UIColor redColor];
    }
}
-(void)setColorOfCurrentHumidityHome
{
    float difference = fabsf(homeAppDelegate.setHumidity - homeAppDelegate.currentHumidity);
    
    if(difference <4)
    {
        self.currentHumidityLabel.textColor = [UIColor greenColor];
    }
    else
    {
        
        self.currentHumidityLabel.textColor = [UIColor redColor];
    }
}
-(void)setColorOfCurrentCarbonHome
{
    float isCO2LevelTooHigh = (homeAppDelegate.setCO2 - homeAppDelegate.currentCO2);
    
    if(isCO2LevelTooHigh >0)
    {
        self.currentCarbonLabel.textColor = [UIColor greenColor];
    }
    else
    {
        
        self.currentCarbonLabel.textColor = [UIColor redColor];
    }
}
-(void)setColorOfCurrentWaterHome
{
    float isWaterConsumptionTooMuch = (homeAppDelegate.setWater - homeAppDelegate.currentWater);
    
    if(isWaterConsumptionTooMuch >0)
    {
        self.currentWaterLabel.textColor = [UIColor greenColor];
    }
    else
    {
        
        self.currentWaterLabel.textColor = [UIColor redColor];
    }
}
-(void)setColorOfCurrentPowerHome
{
    float isPowerConsumptionTooMuch = (homeAppDelegate.setPower - homeAppDelegate.currentPower);
    
    if(isPowerConsumptionTooMuch >0)
    {
        self.currentEnergyLabel.textColor = [UIColor greenColor];
    }
    else
    {
        
        self.currentEnergyLabel.textColor = [UIColor redColor];
    }
}
- (IBAction)refreshButton:(id)sender {
    [self updateUI];
}
-(void)updateUI
{
    
        /// EVERY TIME THE VIEW LOADS FIND OUT WHAT THE CURRENT TEMPERATURE IS AND SET THE LABEL
 
   
    NSString *strURL = [NSString stringWithFormat:@"http://people.cs.clemson.edu/~jacosta/getLastTemperature.php"];
    NSError *error = nil;
    NSString *returnString;
    returnString = [[NSString alloc] init];
    returnString = [NSString stringWithContentsOfURL:[NSURL URLWithString:strURL]  encoding:NSUTF8StringEncoding error:&error];
    
    homeAppDelegate.currentTemperature = [returnString floatValue];
    
    self.currentTempLabel.text = [NSString stringWithFormat:@"%.1lf", homeAppDelegate.currentTemperature];
    
        // EVERYTIME THE VIEW LOADS FIND OUT WHAT THE IDEAL TEMPERATURE IS AND SET THE LABEL
   
        //////////////
    NSString *strURL2 = [NSString stringWithFormat:@"http://people.cs.clemson.edu/~jacosta/getIdealTemp.php"];
    NSError *error2 = nil;
    NSString *returnString2;
    returnString2 = [[NSString alloc] init];
    returnString2 = [NSString stringWithContentsOfURL:[NSURL URLWithString:strURL2]  encoding:NSUTF8StringEncoding error:&error2];
    
    homeAppDelegate.setTemperature = [returnString2 floatValue];
    
        //////////////
    self.idealTempLabel.text = [NSString stringWithFormat:@"Set: %.1lf deg", homeAppDelegate.setTemperature];
    [self setColorOfCurrentTempHome];
    
    
        /// EVERY TIME THE VIEW LOADS FIND OUT WHAT THE CURRENT HUMIDITY IS AND SET THE LABEL
  
        /////////////////
    NSString *strURL3 = [NSString stringWithFormat:@"http://people.cs.clemson.edu/~jacosta/getLastHumidity.php"];
    NSError *error3 = nil;
    NSString *returnString3;
    returnString3 = [[NSString alloc] init];
    returnString3 = [NSString stringWithContentsOfURL:[NSURL URLWithString:strURL3]  encoding:NSUTF8StringEncoding error:&error3];
    
    homeAppDelegate.currentHumidity = (int)[returnString3 integerValue];
    
        /////////////////
    self.currentHumidityLabel.text = [NSString stringWithFormat:@"%d", homeAppDelegate.currentHumidity];
    
        // EVERYTIME THE VIEW LOADS FIND OUT WHAT THE IDEAL Humidity IS AND SET THE LABEL
 
        ////////////////
    NSString *strURL4 = [NSString stringWithFormat:@"http://people.cs.clemson.edu/~jacosta/getIdealHumidity.php"];
    NSError *error4 = nil;
    NSString *returnString4;
    returnString4 = [[NSString alloc] init];
    returnString4 = [NSString stringWithContentsOfURL:[NSURL URLWithString:strURL4]  encoding:NSUTF8StringEncoding error:&error4];
    
    homeAppDelegate.setHumidity = (int)[returnString4 integerValue];
    
        ////////////////
    
    self.idealHumidityLabel.text = [NSString stringWithFormat:@"Set: %d%%", homeAppDelegate.setHumidity];
    [self setColorOfCurrentHumidityHome];
    
    
        /// EVERY TIME THE VIEW LOADS FIND OUT WHAT THE CURRENT WATER CONSUMPTION IS AND SET THE LABEL
   
        /////////////////
    NSString *strURL5 = [NSString stringWithFormat:@"http://people.cs.clemson.edu/~jacosta/getLastWater.php"];
    NSError *error5 = nil;
    NSString *returnString5;
    returnString5 = [[NSString alloc] init];
    returnString5 = [NSString stringWithContentsOfURL:[NSURL URLWithString:strURL5]  encoding:NSUTF8StringEncoding error:&error5];
    
    homeAppDelegate.currentWater = (int)[returnString5 integerValue];
    
    
    
        /////////////////
    self.currentWaterLabel.text = [NSString stringWithFormat:@"%d", homeAppDelegate.currentWater];
    
        // EVERYTIME THE VIEW LOADS FIND OUT WHAT THE IDEAL WATER CONSUMPTION IS AND SET THE LABEL
   
    
        ////////////////
    NSString *strURL6 = [NSString stringWithFormat:@"http://people.cs.clemson.edu/~jacosta/getIdealWater.php"];
    NSError *error6 = nil;
    NSString *returnString6;
    returnString6 = [[NSString alloc] init];
    returnString6 = [NSString stringWithContentsOfURL:[NSURL URLWithString:strURL6]  encoding:NSUTF8StringEncoding error:&error6];
    
    homeAppDelegate.setWater = (int)[returnString6 integerValue];
        ///////////////
    self.idealWaterLabel.text = [NSString stringWithFormat:@"Goal: %d Gal", homeAppDelegate.setWater];
    [self setColorOfCurrentWaterHome];
        /// EVERY TIME THE VIEW LOADS FIND OUT WHAT THE CURRENT POWER CONSUMPTION IS AND SET THE LABEL
    
        //////////////////
    NSString *strURL7 = [NSString stringWithFormat:@"http://people.cs.clemson.edu/~jacosta/getLastPower.php"];
    NSError *error7 = nil;
    NSString *returnString7;
    returnString7 = [[NSString alloc] init];
    returnString7 = [NSString stringWithContentsOfURL:[NSURL URLWithString:strURL7]  encoding:NSUTF8StringEncoding error:&error7];
    
    homeAppDelegate.currentPower = (int)[returnString7 integerValue];
    
    
    
    
        /////////////////
    self.currentEnergyLabel.text = [NSString stringWithFormat:@"%d", homeAppDelegate.currentPower];
    
        // EVERYTIME THE VIEW LOADS FIND OUT WHAT THE IDEAL POWER CONSUMPTION IS AND SET THE LABEL
   
        ///////////////
    
    NSString *strURL8 = [NSString stringWithFormat:@"http://people.cs.clemson.edu/~jacosta/getIdealPower.php"];
    NSError *error8 = nil;
    NSString *returnString8;
    returnString8 = [[NSString alloc] init];
    returnString8 = [NSString stringWithContentsOfURL:[NSURL URLWithString:strURL8]  encoding:NSUTF8StringEncoding error:&error8];
    
    homeAppDelegate.setPower = (int)[returnString8 integerValue];
    
    
    
        //////////////
    
    self.idealEnergyLabel.text = [NSString stringWithFormat:@"Goal: %d kWh", homeAppDelegate.setPower];
    [self setColorOfCurrentPowerHome];
        /// EVERY TIME THE VIEW LOADS FIND OUT WHAT THE CURRENT CO2 LEVEL IS AND SET THE LABEL
    
        ///////////////////
    NSString *strURL9 = [NSString stringWithFormat:@"http://people.cs.clemson.edu/~jacosta/getLastCO2.php"];
    NSError *error9 = nil;
    NSString *returnString9;
    returnString9 = [[NSString alloc] init];
    returnString9 = [NSString stringWithContentsOfURL:[NSURL URLWithString:strURL9]  encoding:NSUTF8StringEncoding error:&error9];
    
    homeAppDelegate.currentCO2 = (int)[returnString9 integerValue];
    
    
        //////////////////
    self.currentCarbonLabel.text = [NSString stringWithFormat:@"%d", homeAppDelegate.currentCO2];
    
        // EVERYTIME THE VIEW LOADS FIND OUT WHAT THE IDEAL CO2 LEVEL IS AND SET THE LABEL
   
        ////////////////////
    NSString *strURL10 = [NSString stringWithFormat:@"http://people.cs.clemson.edu/~jacosta/getIdealCO2.php"];
    NSError *error10 = nil;
    NSString *returnString10;
    returnString10 = [[NSString alloc] init];
    returnString10 = [NSString stringWithContentsOfURL:[NSURL URLWithString:strURL10]  encoding:NSUTF8StringEncoding error:&error10];
    
    homeAppDelegate.setCO2 = (int)[returnString10 integerValue];
    
    
        ////////////////////
    self.idealCarbonLabel.text = [NSString stringWithFormat:@"Set: %d PPM", homeAppDelegate.setCO2];
    [self setColorOfCurrentCarbonHome];
}
-(void)timerSecondsDashboard
{
    secondsDashboard = secondsDashboard +1;
    if(secondsDashboard >59)
    {
            // update the home screen every minute
        [self updateUI];
            // stop the timer. Then reset it.
        [timerDashboard invalidate];
        secondsDashboard =0;
        timerDashboard = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerSecondsDashboard) userInfo:nil repeats:YES];
    }
}
-(void) viewDidLoad{
    
    homeAppDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [self updateUI];
    //set content view's constraints at runtime, instead of with placeholder constraints used in IB.
    NSLayoutConstraint *leftConstraint = [NSLayoutConstraint constraintWithItem:self.contentView
                                                                      attribute:NSLayoutAttributeLeading
                                                                      relatedBy:0
                                                                         toItem:self.view
                                                                      attribute:NSLayoutAttributeLeft
                                                                     multiplier:1.0
                                                                       constant:0];
    [self.view addConstraint:leftConstraint];
    
    NSLayoutConstraint *rightConstraint = [NSLayoutConstraint constraintWithItem:self.contentView
                                                                       attribute:NSLayoutAttributeTrailing
                                                                       relatedBy:0
                                                                          toItem:self.view
                                                                       attribute:NSLayoutAttributeRight
                                                                      multiplier:1.0
                                                                        constant:0];
    [self.view addConstraint:rightConstraint];

    //DISABLED FOR NOW. MESSES WITH SCROLLVIEW POSITIONING
    // Start the timer
      timerDashboard = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerSecondsDashboard) userInfo:nil repeats:YES];
    
    //set the nav bar tint
    //only need to do this once here, and in no other controllers.
    NSArray *ver = [[UIDevice currentDevice].systemVersion componentsSeparatedByString:@"."];
    if ([[ver objectAtIndex:0] intValue] >= 7) {
        // iOS 7.0 or later
        self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:38.0f/255.0f green:38.0f/255.0f blue:38.0f/255.0f alpha:1.0f];
        self.navigationController.navigationBar.translucent = NO;
    }else {
        // iOS 6.1 or earlier
        self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:38.0f/255.0f green:38.0f/255.0f blue:38.0f/255.0f alpha:1.0f];
    }
    
    // Set sound effects
    [self.tempButton setSoundNamed:@"tap-resonant.aif" forControlEvent:UIControlEventTouchDown];
    [self.humidityButton setSoundNamed:@"tap-resonant.aif" forControlEvent:UIControlEventTouchDown];
    [self.waterButton setSoundNamed:@"tap-resonant.aif" forControlEvent:UIControlEventTouchDown];
    [self.energyButton setSoundNamed:@"tap-resonant.aif" forControlEvent:UIControlEventTouchDown];
    [self.carbonButton setSoundNamed:@"tap-resonant.aif" forControlEvent:UIControlEventTouchDown];
    
}

@end