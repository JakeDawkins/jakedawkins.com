//
//  LightingViewController.m
//  2.SD.Home.Control-App
//
//  Created by Jake Dawkins on 11/18/14.
//  Copyright (c) 2014 Thunder Ducklings. All rights reserved.
//
/*
 ///////////////////////////////////////
 
 use this link to find the bridge IP address
 https://www.meethue.com/api/nupnp
 
 ////////////////////////////////////////
 */

#import "LightingViewController.h"
#import "AppDelegate.h"
int numberOfLights;

@interface LightingViewController()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) IBOutlet UIButton *onDefault;
@property (strong, nonatomic) IBOutlet UIButton *offButton;
@property (strong, nonatomic) IBOutlet UISlider *brightnessSlider;
@property (strong, nonatomic) IBOutlet UISlider *colorSlider;




@end
AppDelegate *lightsAppDelegate;
BOOL *hasShownNotification = FALSE;
NSString *macAddress;
NSString *ipAddress;
    //353 H IP ADDRESS --->
NSString *ipAddress1 = @"192.168.4.1";
NSString *kHueAPIUserName = @"newdeveloper";

int lightNum=0;
int currentHue = 15000;
int currentSat = 100;
int currentBrightness = 255;

NSMutableArray *lightsHue;
NSMutableArray *myLights;
NSMutableArray *myLightBrightness;
NSMutableArray *myLightStatus;
NSMutableArray *myLightReachability;
NSMutableArray *lightDescription;
NSMutableArray *IP;
BOOL continueLoading = false;
BOOL enableButtons = false;
@implementation LightingViewController

-(void)viewWillAppear:(BOOL)animated {
    //check if user is an admin
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    //NSLog(@"login info:\n");
    //NSLog([defaults objectForKey:@"username"]);
    //NSLog([defaults objectForKey:@"password"]);
    
    NSString *strURL1 = [NSString stringWithFormat:@"http://people.cs.clemson.edu/~jacosta/adminLogin.php?username=%@&password=%@", [defaults objectForKey:@"username"], [defaults objectForKey:@"password"]];
    NSError *error1 = nil;
    NSString *returnString1;
    returnString1 = [[NSString alloc] init];
    returnString1 = [NSString stringWithContentsOfURL:[NSURL URLWithString:strURL1]  encoding:NSUTF8StringEncoding error:&error1];
    
    int isAdmin = (int)[returnString1 integerValue];
    
    if(isAdmin==1) {
        NSLog(@"isAdmin");
        lightsAppDelegate.isAdmin = true;
    } else {
        lightsAppDelegate.isAdmin = false;
        NSLog(@"isNotAdmin");
    }
    //end admin check
}



-(void)enableOrdisableButton: (BOOL) TorF
{
    
    self.onDefault.enabled = TorF;
    self.offButton.enabled = TorF;
    self.brightnessSlider.enabled=TorF;
    self.colorSlider.enabled=TorF;
    
 
}

-(void)viewDidLoad{
    [super viewDidLoad];
    lightsAppDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
   
    if(lightsAppDelegate.isAdmin)
    {
        [self enableOrdisableButton:true];
    }
    else
    {
        [self enableOrdisableButton:false];
    }
    
    myLights = [[NSMutableArray alloc] initWithObjects:nil];
    myLightBrightness = [[NSMutableArray alloc]initWithObjects:nil];
    myLightStatus = [[NSMutableArray alloc] initWithObjects:nil];
    myLightReachability =[[NSMutableArray alloc] initWithObjects:nil];
    lightDescription = [[NSMutableArray alloc]initWithObjects: nil];
    IP = [[NSMutableArray alloc]initWithObjects: nil];

    lightsHue = [[NSMutableArray alloc]initWithObjects: nil];    NSURLRequest *theRequest=[NSURLRequest requestWithURL:[NSURL URLWithString:@"https://www.meethue.com/api/nupnp"]
                                              cachePolicy:NSURLRequestUseProtocolCachePolicy
                                          timeoutInterval:60.0];
    NSError         * e;
    NSData      *data = [NSURLConnection sendSynchronousRequest:theRequest returningResponse:nil error:&e];
    
    
    NSString *strResult = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    if([strResult isEqualToString:@"[]"])
    {
            //No bridge found on network
            // ask user to enter ip address
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"No Bridge On Network"
                                                        message:@"Please connect to the same network the bridge is on."
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
        continueLoading = false;
    }
    else
    {
            // parsing
        continueLoading = true;

        NSString *jsonData = [NSString stringWithFormat:@"%@", strResult];
        NSRange searchRange = NSMakeRange(0,jsonData.length);
        NSRange foundRange;
        NSString *substring = @"internalipaddress";
        NSString *scanUntilThisSubstring = @"macaddress";
        NSRange secondRange;
        NSInteger lengthOfNameString;
        NSInteger startLocation;
        while (searchRange.location < jsonData.length) {
            searchRange.length = jsonData.length-searchRange.location;
            foundRange = [jsonData rangeOfString:substring options:NSCaseInsensitiveSearch range:searchRange];
            
            if (foundRange.location != NSNotFound) {
                    // we found the first substring
                secondRange = [jsonData rangeOfString:scanUntilThisSubstring options:NSCaseInsensitiveSearch range:searchRange];
                if(secondRange.location !=NSNotFound)
                {
                        // we found the second substring too!
                    searchRange.location = foundRange.location+foundRange.length;
                    startLocation = searchRange.location;
                    searchRange.location = secondRange.location +secondRange.length;
                    lengthOfNameString = searchRange.location-startLocation;
                        [IP addObject:[jsonData substringWithRange:NSMakeRange(startLocation+3, lengthOfNameString-16)]];
                    
                }
                
            } else {
                    // no more substring to find
                break;
            }

    }
       
    }
    if(IP.count ==1)
    {
    ipAddress1 = [NSString stringWithFormat:@"%@", IP[0]];
    }
    else
    {
            // there was not an IP address found
    }
    numberOfLights =0;
    
    if(continueLoading)
    {
        if(lightsAppDelegate.isAdmin)
        {
            
            [self enableOrdisableButton:true];
            enableButtons = true;
        }
        
      self.tableView.dataSource = self;
self.tableView.delegate = self;  
    [self updateUI];
    
    
  
    }
    if(!enableButtons)
    {
        [self enableOrdisableButton:false];

    }
}



     
         
//table delegate methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return numberOfLights;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *cellIdentifier = @"lightBulb";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    /*
    NSString *cellDescription = @"Light is off";
    NSString *isLightOn = [myLightStatus objectAtIndex:indexPath.row];
    NSString *isReachable = [myLightReachability objectAtIndex:indexPath.row];
    if([isLightOn isEqual:@"1"])
        cellDescription = @"Light is on";
    if([isReachable isEqual:@"0"])
        cellDescription = @"Light is off";
    
    lightDescription[indexPath.row] = cellDescription;
     */
        //tag 100 is name label tag in UI Builder.
    UILabel *nameLabel = (UILabel *)[cell viewWithTag:100];
    [nameLabel setText:[myLights objectAtIndex:[indexPath row]]];
    
        //tag 200 is name label tag in UI Builder.
    /*
    UILabel *descLabel = (UILabel *)[cell viewWithTag:200];
    [descLabel setText:[lightDescription objectAtIndex:[indexPath row]]];
    */
    
     UILabel *descLabel = (UILabel *)[cell viewWithTag:200];
     [descLabel setText:@""];
    
    return cell;
    
}


-(void)updateUI
{
    
    [lightDescription removeAllObjects];
   
    for(int i=0; i <numberOfLights;i++)
    {
        
        [lightDescription addObject:@"Light Off"];
    }
    NSString* lightList = [NSString stringWithFormat:@"http://%@/api/%@/lights", ipAddress1, kHueAPIUserName];
    [self getLight:[NSURL URLWithString:lightList] second:@"GET"];
    /*
    NSLog(@"Lights, brightness, status, reachability, hue");
    NSLog(@"%@", myLights);
    NSLog(@"%@", myLightBrightness);
    NSLog(@"%@", myLightStatus);
    NSLog(@"%@", myLightReachability);
    NSLog(@"%@", lightsHue);
    NSLog(@"%@", lightDescription);
        [self.tableView reloadData];
     */
    
    
}
-(void)getLight:(NSURL*) url second:(NSString*) method
{
    [lightsHue removeAllObjects];
    [myLights removeAllObjects];
    [myLightBrightness removeAllObjects];
    [myLightStatus removeAllObjects];
    [myLightReachability removeAllObjects];
    
    NSMutableURLRequest* request = [[NSMutableURLRequest alloc] init];
    [request setURL:url];
    [self getLightBrightness:url second:method];
    [self getLightStates:url second:method];
    [request setHTTPMethod:method];
    
    NSData *data=[NSData dataWithContentsOfURL:url];
    NSError *error=nil;
    NSArray *response=[NSJSONSerialization JSONObjectWithData:data options:
                       NSJSONReadingMutableContainers error:&error];

    NSString *jsonData = [NSString stringWithFormat:@"%@", response];
    NSRange searchRange = NSMakeRange(0,jsonData.length);
    NSRange foundRange;
    NSString *substring = @"name = ";
    NSString *scanUntilThisSubstring = @"pointsymbol =";
    NSRange secondRange;
    NSInteger lengthOfNameString;
    NSInteger startLocation;
    while (searchRange.location < jsonData.length) {
        searchRange.length = jsonData.length-searchRange.location;
        foundRange = [jsonData rangeOfString:substring options:NSCaseInsensitiveSearch range:searchRange];
        
        if (foundRange.location != NSNotFound) {
                // we found the first substring
            numberOfLights = numberOfLights +1;
            secondRange = [jsonData rangeOfString:scanUntilThisSubstring options:NSCaseInsensitiveSearch range:searchRange];
            if(secondRange.location !=NSNotFound)
            {
                    // we found the second substring too!
                searchRange.location = foundRange.location+foundRange.length;
                startLocation = searchRange.location;
                searchRange.location = secondRange.location +secondRange.length;
                lengthOfNameString = searchRange.location-startLocation;
                NSString *lightBulbRawDataName = [jsonData substringWithRange:NSMakeRange(startLocation, lengthOfNameString-19)];
                NSString *LightBulb = [lightBulbRawDataName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                LightBulb = [LightBulb stringByReplacingOccurrencesOfString:@"\"" withString:@""];
                LightBulb = [LightBulb stringByReplacingOccurrencesOfString:@";" withString:@""];
                
                [myLights addObject:LightBulb];
            
            }
            
        } else {
                // no more substring to find
            break;
        }
        
        
    }
    [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
}
 
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    lightNum = (int)indexPath.row+1;
    self.brightnessSlider.value = [myLightBrightness[lightNum-1] floatValue];
    self.colorSlider.value = (int)[lightsHue[indexPath.row] floatValue];
    
}

-(void) getLightStates:(NSURL *) url second:(NSString *)method
{
    NSMutableURLRequest* request = [[NSMutableURLRequest alloc] init];
    [request setURL:url];
    [request setHTTPMethod:method];
    
    NSData *data=[NSData dataWithContentsOfURL:url];
    NSError *error=[NSError new];
    NSArray *response=[NSJSONSerialization JSONObjectWithData:data options:
                       NSJSONReadingMutableContainers error:&error];

    NSString *jsonData = [NSString stringWithFormat:@"%@", response];
    NSRange searchRange = NSMakeRange(0,jsonData.length);
    NSRange foundRange;
    NSString *substring = @"hue =";
    NSString *scanUntilThisSubstring = @"reachable =";
    NSRange secondRange;
    NSInteger lengthOfNameString;
    NSInteger startLocation;
    while (searchRange.location < jsonData.length) {
        searchRange.length = jsonData.length-searchRange.location;
        foundRange = [jsonData rangeOfString:substring options:NSCaseInsensitiveSearch range:searchRange];
        
        if (foundRange.location != NSNotFound) {
                // we found the first substring
            secondRange = [jsonData rangeOfString:scanUntilThisSubstring options:NSCaseInsensitiveSearch range:searchRange];
            if(secondRange.location !=NSNotFound)
            {
                
                    // we found the second substring too!
                searchRange.location = foundRange.location+foundRange.length;
                startLocation = searchRange.location;
                searchRange.location = secondRange.location +secondRange.length;
                lengthOfNameString = searchRange.location-startLocation;
                [lightsHue addObject:[jsonData substringWithRange:NSMakeRange(startLocation+1,5)]];
                [myLightStatus addObject:[jsonData substringWithRange:NSMakeRange(startLocation+25, lengthOfNameString-50)]];
                [myLightReachability addObject:[jsonData substringWithRange:NSMakeRange(startLocation+52, lengthOfNameString-50)]];
            }
            
        } else {
                // no more substring to find
            break;
        }
        
        
    }
    [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
}
-(void) getLightBrightness:(NSURL *) url second:(NSString *)method
{
    
    NSMutableURLRequest* request = [[NSMutableURLRequest alloc] init];
    [request setURL:url];
    [request setHTTPMethod:method];
    
    NSData *data=[NSData dataWithContentsOfURL:url];
    NSError *error=nil;
    NSArray *response=[NSJSONSerialization JSONObjectWithData:data options:
                       NSJSONReadingMutableContainers error:&error];

    NSString *jsonData = [NSString stringWithFormat:@"%@", response];
    NSRange searchRange = NSMakeRange(0,jsonData.length);
    NSRange foundRange;
    NSString *substring = @"bri =";
    NSString *scanUntilThisSubstring = @"colormode =";
    NSRange secondRange;
    NSInteger lengthOfNameString;
    NSInteger startLocation;
    while (searchRange.location < jsonData.length) {
        searchRange.length = jsonData.length-searchRange.location;
        foundRange = [jsonData rangeOfString:substring options:NSCaseInsensitiveSearch range:searchRange];
        
        if (foundRange.location != NSNotFound) {
                // we found the first substring
            secondRange = [jsonData rangeOfString:scanUntilThisSubstring options:NSCaseInsensitiveSearch range:searchRange];
            if(secondRange.location !=NSNotFound)
            {
                
                    // we found the second substring too!
                searchRange.location = foundRange.location+foundRange.length;
                startLocation = searchRange.location;
                searchRange.location = secondRange.location +secondRange.length;
                lengthOfNameString = searchRange.location-startLocation;
                [myLightBrightness addObject:[jsonData substringWithRange:NSMakeRange(startLocation+1, lengthOfNameString-26)]];
            }
            
        } else {
                // no more substring to find
            break;
        }
        
        
    }
    [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    
}
 
- (IBAction)turnOnLight:(id)sender {
    
    NSString* onCommand = @"{\"on\":true,\"bri\":255,\"sat\":100,\"transitiontime\":10,\"effect\":\"none\",\"hue\":15000}";
    NSString* lightStateURL = [NSString stringWithFormat:@"http://%@/api/%@/lights/%d/state", ipAddress1, kHueAPIUserName, lightNum];
    updateLight([NSURL URLWithString:lightStateURL], @"PUT", onCommand);
    currentHue = 15000;
    currentSat =100;
        [self updateUI];
    self.brightnessSlider.value = 255;

}

- (IBAction)turnOffLight:(id)sender {
    
    
    NSString* onCommand = [NSString stringWithFormat:@"{\"on\":false,\"bri\":%d,\"sat\":%d,\"transitiontime\":10,\"effect\":\"none\",\"hue\":%d}", (int)[myLightBrightness[lightNum-1] integerValue], currentSat, currentHue];
    NSString* lightStateURL = [NSString stringWithFormat:@"http://%@/api/%@/lights/%d/state", ipAddress1, kHueAPIUserName, lightNum];
    updateLight([NSURL URLWithString:lightStateURL], @"PUT", onCommand);
    currentHue = 15000;
    currentSat =100;
        [self updateUI];
}




void updateLight(NSURL* url, NSString* method, NSString* jsonBody)
{
    NSMutableURLRequest* request = [[NSMutableURLRequest alloc] init];
    [request setURL:url];
    NSData* bodyData = [jsonBody dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    NSString* postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[bodyData length]];
    
    [request setHTTPMethod:method];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:bodyData];
    
    [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
}

- (IBAction)brightnessSlider:(id)sender {
    
    NSString* onCommand = [NSString stringWithFormat:@"{\"on\":true,\"bri\":%d,\"sat\":%d,\"transitiontime\":10,\"effect\":\"none\",\"hue\":%d}", (int)self.brightnessSlider.value, currentSat, currentHue];
    NSString* lightStateURL = [NSString stringWithFormat:@"http://%@/api/%@/lights/%d/state", ipAddress1, kHueAPIUserName, lightNum];
    updateLight([NSURL URLWithString:lightStateURL], @"PUT", onCommand);
    currentBrightness = (int)self.brightnessSlider.value;

}

- (IBAction)colorSlider:(id)sender {
    
    currentSat = 255;
    NSString* onCommand = [NSString stringWithFormat:@"{\"on\":true,\"bri\":%d,\"sat\":%d,\"transitiontime\":10,\"effect\":\"none\",\"hue\":%d}", currentBrightness, currentSat, (int)self.colorSlider.value];
    NSString* lightStateURL = [NSString stringWithFormat:@"http://%@/api/%@/lights/%d/state", ipAddress1, kHueAPIUserName, lightNum];
    updateLight([NSURL URLWithString:lightStateURL], @"PUT", onCommand);
    currentHue = (int)self.colorSlider.value;
    
    
}
@end