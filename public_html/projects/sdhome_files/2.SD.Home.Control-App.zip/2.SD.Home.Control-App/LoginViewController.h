//
//  LoginViewController.h
//  2.SD.Home.Control-App
//
//  Created by Jake Dawkins on 11/16/14.
//  Copyright (c) 2014 Thunder Ducklings. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController <UITextFieldDelegate>

@end