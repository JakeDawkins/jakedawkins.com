//
//  main.m
//  2.SD.Home.Control-App
//
//  Created by Jake Dawkins on 11/9/14.
//  Copyright (c) 2014 Thunder Ducklings. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
