//
//  AppDelegate.h
//  2.SD.Home.Control.Simulator
//
//  Created by Jake Dawkins on 11/30/14.
//  Copyright (c) 2014 Thunder Ducklings. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

