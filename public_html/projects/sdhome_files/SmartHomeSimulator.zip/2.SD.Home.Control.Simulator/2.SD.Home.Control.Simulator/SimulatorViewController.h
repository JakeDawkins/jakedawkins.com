//
//  SimulatorViewController.h
//  2.SD.Home.Control.Simulator
//
//  Created by Jake Dawkins on 11/30/14.
//  Copyright (c) 2014 Thunder Ducklings. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Sensor.h"
#import "ToggleSensor.h"

@interface SimulatorViewController : UIViewController

@end