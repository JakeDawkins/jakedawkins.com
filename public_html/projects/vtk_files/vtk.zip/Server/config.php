<?php

$DBServer = "mysql1.cs.clemson.edu";
$DBName = "vtk_db_zrrm";
$DBUser = "vtk_db_de9b";
$DBPass = "vtk_primaryuser";

?>
