//
//  VTKAcknowlegmentsViewController.m
//  jacksod.a2
//
//  Created by Jake Dawkins on 9/23/14.
//  Copyright (c) 2014 Jake Dawkins. All rights reserved.
//

#import "VTKAcknowlegmentsViewController.h"

@interface VTKAcknowlegmentsViewController ()

@end

@implementation VTKAcknowlegmentsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    self.automaticallyAdjustsScrollViewInsets = NO;
}


@end
