//
//  main.m
//  jacksod.a4
//
//  Created by Jake Dawkins on 9/20/14.
//  Copyright (c) 2014 Jake Dawkins. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "VTKAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([VTKAppDelegate class]));
    }
}
